// Application Data
const fraudData = {
    "fraudIndicators": {
        "videoContent": [
            {"id": 1, "indicator": "Promises of easy money/get-rich-quick schemes", "riskLevel": "high", "description": "Videos promoting unrealistic financial gains with minimal effort"},
            {"id": 2, "indicator": "Fake giveaways with suspicious requirements", "riskLevel": "high", "description": "Giveaways requiring personal information or payments"},
            {"id": 3, "indicator": "Investment opportunities with unrealistic returns", "riskLevel": "high", "description": "Investment schemes promising guaranteed high returns"},
            {"id": 4, "indicator": "Impersonation of celebrities or verified accounts", "riskLevel": "high", "description": "Fake accounts mimicking famous personalities"},
            {"id": 5, "indicator": "Urgent language creating time pressure", "riskLevel": "medium", "description": "Content using urgency to pressure quick decisions"},
            {"id": 6, "indicator": "Requests for personal information", "riskLevel": "high", "description": "Videos asking for sensitive personal or financial data"},
            {"id": 7, "indicator": "Links to external websites", "riskLevel": "medium", "description": "Suspicious external links in video descriptions"},
            {"id": 8, "indicator": "Cryptocurrency promotion schemes", "riskLevel": "high", "description": "Unverified crypto investment opportunities"},
            {"id": 9, "indicator": "Fake product advertisements", "riskLevel": "medium", "description": "Misleading product promotions with false claims"},
            {"id": 10, "indicator": "Romance scam patterns", "riskLevel": "high", "description": "Content designed to build fake romantic relationships"}
        ],
        "accountBehavior": [
            {"id": 11, "indicator": "Low follower count with high engagement on specific posts", "riskLevel": "medium", "description": "Suspicious engagement patterns suggesting manipulation"},
            {"id": 12, "indicator": "Recently created account", "riskLevel": "low", "description": "New accounts with limited history"},
            {"id": 13, "indicator": "Missing profile picture or stolen images", "riskLevel": "medium", "description": "Accounts using default or stolen profile images"},
            {"id": 14, "indicator": "Inconsistent content quality", "riskLevel": "low", "description": "Dramatic variations in content production quality"},
            {"id": 15, "indicator": "Repetitive content patterns", "riskLevel": "medium", "description": "Accounts posting similar content repeatedly"},
            {"id": 16, "indicator": "Bio links to questionable websites", "riskLevel": "high", "description": "Profile links directing to suspicious external sites"},
            {"id": 17, "indicator": "Fake verification attempts", "riskLevel": "high", "description": "Accounts falsely claiming verification status"},
            {"id": 18, "indicator": "Unusual follower/following ratios", "riskLevel": "low", "description": "Abnormal ratios suggesting artificial growth"},
            {"id": 19, "indicator": "Account with few followers but many sponsored posts", "riskLevel": "medium", "description": "Accounts with disproportionate promotional content"},
            {"id": 20, "indicator": "Profile inconsistencies", "riskLevel": "medium", "description": "Contradictory information across profile elements"}
        ],
        "behavioralPatterns": [
            {"id": 21, "indicator": "Mass messaging to followers", "riskLevel": "high", "description": "Automated or bulk messaging to multiple users"},
            {"id": 22, "indicator": "Automated responses", "riskLevel": "medium", "description": "Bot-like responses to comments and messages"},
            {"id": 23, "indicator": "Posting frequency spikes", "riskLevel": "low", "description": "Unusual increases in posting activity"},
            {"id": 24, "indicator": "Copy-paste comments across videos", "riskLevel": "medium", "description": "Identical comments posted on multiple videos"},
            {"id": 25, "indicator": "Targeting specific demographic groups", "riskLevel": "medium", "description": "Content specifically targeting vulnerable populations"},
            {"id": 26, "indicator": "Cross-platform identical content", "riskLevel": "low", "description": "Same content posted across multiple platforms"},
            {"id": 27, "indicator": "Suspicious interaction patterns", "riskLevel": "medium", "description": "Unnatural patterns in likes, shares, and comments"},
            {"id": 28, "indicator": "Bot-like engagement timing", "riskLevel": "medium", "description": "Engagement occurring at non-human intervals"},
            {"id": 29, "indicator": "Rapid content deletion after posting", "riskLevel": "high", "description": "Content quickly removed after achieving viral status"},
            {"id": 30, "indicator": "Coordinated inauthentic behavior", "riskLevel": "high", "description": "Multiple accounts working together artificially"}
        ]
    },
    "scamTypes": [
        {"type": "Investment Scams", "description": "Fake cryptocurrency and trading opportunities", "prevalence": "25%"},
        {"type": "Fake Giveaways", "description": "Fraudulent prize and money giveaway schemes", "prevalence": "30%"},
        {"type": "Romance Scams", "description": "Fake romantic relationships for financial exploitation", "prevalence": "15%"},
        {"type": "Product Scams", "description": "Fake or misleading product advertisements", "prevalence": "20%"},
        {"type": "Phishing Attempts", "description": "Attempts to steal personal information", "prevalence": "10%"}
    ],
    "safetyTips": [
        "Never share personal or financial information through TikTok messages",
        "Be skeptical of offers that seem too good to be true",
        "Verify celebrity accounts by checking for official verification badges",
        "Don't click on suspicious links in video descriptions or comments",
        "Report suspicious content using TikTok's built-in reporting features",
        "Research investment opportunities independently before participating",
        "Use strong, unique passwords and enable two-factor authentication",
        "Be cautious of urgent requests for money or personal information"
    ],
    "recentScans": [
        {"url": "https://tiktok.com/@user1/video/123", "riskScore": 85, "timestamp": "2025-09-19T08:30:00Z", "primaryThreat": "Investment Scam"},
        {"url": "https://tiktok.com/@user2/video/456", "riskScore": 25, "timestamp": "2025-09-19T08:15:00Z", "primaryThreat": "None detected"},
        {"url": "https://tiktok.com/@user3/video/789", "riskScore": 70, "timestamp": "2025-09-19T08:00:00Z", "primaryThreat": "Fake Giveaway"},
        {"url": "https://tiktok.com/@user4/video/321", "riskScore": 15, "timestamp": "2025-09-19T07:45:00Z", "primaryThreat": "None detected"},
        {"url": "https://tiktok.com/@user5/video/654", "riskScore": 90, "timestamp": "2025-09-19T07:30:00Z", "primaryThreat": "Phishing Attempt"}
    ]
};

// Global variables
let fraudChart = null;
let currentSection = 'scanner';

// Initialize application when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    console.log('Initializing TikTok Fraud Checker...');
    
    try {
        initializeNavigation();
        initializeScanner();
        initializeDatabase();
        initializeEducation();
        initializeReports();
        initializeModal();
        
        console.log('Application initialized successfully');
    } catch (error) {
        console.error('Error initializing application:', error);
    }
});

// Navigation functionality
function initializeNavigation() {
    const navItems = document.querySelectorAll('.nav__item');
    
    navItems.forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            const sectionName = this.dataset.section;
            switchSection(sectionName);
        });
    });
}

function switchSection(sectionName) {
    // Update navigation
    const navItems = document.querySelectorAll('.nav__item');
    navItems.forEach(item => {
        item.classList.remove('nav__item--active');
        if (item.dataset.section === sectionName) {
            item.classList.add('nav__item--active');
        }
    });
    
    // Update sections
    const sections = document.querySelectorAll('.section');
    sections.forEach(section => {
        section.classList.remove('section--active');
        section.classList.add('hidden');
        if (section.id === sectionName) {
            section.classList.add('section--active');
            section.classList.remove('hidden');
        }
    });
    
    currentSection = sectionName;
    
    // Initialize section-specific functionality
    if (sectionName === 'reports' && !fraudChart) {
        setTimeout(() => {
            try {
                initializeFraudChart();
            } catch (error) {
                console.error('Error initializing fraud chart:', error);
            }
        }, 200);
    }
}

// Scanner functionality
function initializeScanner() {
    const analyzeBtn = document.getElementById('analyzeBtn');
    const videoUrlInput = document.getElementById('videoUrl');
    
    if (analyzeBtn && videoUrlInput) {
        analyzeBtn.addEventListener('click', function(e) {
            e.preventDefault();
            const url = videoUrlInput.value.trim();
            
            if (!url) {
                alert('Please enter a TikTok video URL');
                return;
            }
            
            if (!isValidTikTokURL(url)) {
                alert('Please enter a valid TikTok video URL');
                return;
            }
            
            analyzeVideo(url);
        });
        
        videoUrlInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                analyzeBtn.click();
            }
        });
    }
}

function isValidTikTokURL(url) {
    const tiktokPattern = /^https?:\/\/(www\.)?(tiktok\.com|vm\.tiktok\.com)/i;
    return tiktokPattern.test(url);
}

function analyzeVideo(url) {
    const scanResults = document.getElementById('scanResults');
    const loadingState = document.getElementById('loadingState');
    const analyzeBtn = document.getElementById('analyzeBtn');
    
    if (!scanResults || !loadingState || !analyzeBtn) {
        console.error('Required elements not found for analysis');
        return;
    }
    
    // Show loading state
    scanResults.classList.add('hidden');
    loadingState.classList.remove('hidden');
    analyzeBtn.disabled = true;
    analyzeBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Analyzing...';
    
    // Simulate analysis delay
    setTimeout(() => {
        try {
            const analysis = simulateFraudDetection(url);
            displayResults(analysis);
            
            // Hide loading state
            loadingState.classList.add('hidden');
            scanResults.classList.remove('hidden');
            analyzeBtn.disabled = false;
            analyzeBtn.innerHTML = '<i class="fas fa-search"></i> Analyze Video';
        } catch (error) {
            console.error('Error during analysis:', error);
            loadingState.classList.add('hidden');
            analyzeBtn.disabled = false;
            analyzeBtn.innerHTML = '<i class="fas fa-search"></i> Analyze Video';
            alert('An error occurred during analysis. Please try again.');
        }
    }, 2500);
}

function simulateFraudDetection(url) {
    const suspiciousKeywords = [
        'money', 'cash', 'giveaway', 'free', 'investment', 'crypto', 
        'bitcoin', 'earn', 'rich', 'millionaire', 'prize', 'winner'
    ];
    
    const urlLower = url.toLowerCase();
    let riskScore = Math.floor(Math.random() * 30) + 10; // Base risk 10-40
    let detectedIndicators = [];
    let primaryThreat = 'None detected';
    
    // Check for suspicious keywords
    suspiciousKeywords.forEach(keyword => {
        if (urlLower.includes(keyword)) {
            riskScore += Math.floor(Math.random() * 20) + 15;
        }
    });
    
    // Determine risk level and indicators
    if (riskScore > 70) {
        detectedIndicators = getRandomIndicators(3, 5);
        primaryThreat = getRandomThreat(['Investment Scam', 'Fake Giveaway', 'Phishing Attempt']);
    } else if (riskScore > 40) {
        detectedIndicators = getRandomIndicators(1, 3);
        primaryThreat = getRandomThreat(['Product Scam', 'Fake Giveaway']);
    } else {
        detectedIndicators = getRandomIndicators(0, 2);
    }
    
    // Cap risk score at 100
    riskScore = Math.min(riskScore, 100);
    
    return {
        riskScore,
        indicators: detectedIndicators,
        account: generateAccountAnalysis(riskScore),
        recommendations: generateRecommendations(riskScore),
        primaryThreat
    };
}

function getRandomIndicators(min, max) {
    const allIndicators = [
        ...fraudData.fraudIndicators.videoContent,
        ...fraudData.fraudIndicators.accountBehavior,
        ...fraudData.fraudIndicators.behavioralPatterns
    ];
    
    const count = Math.floor(Math.random() * (max - min + 1)) + min;
    const shuffled = [...allIndicators].sort(() => 0.5 - Math.random());
    return shuffled.slice(0, count);
}

function getRandomThreat(threats) {
    return threats[Math.floor(Math.random() * threats.length)];
}

function generateAccountAnalysis(riskScore) {
    const followers = Math.floor(Math.random() * 100000) + 1000;
    const following = Math.floor(Math.random() * 1000) + 50;
    const accountAge = Math.floor(Math.random() * 365) + 30;
    const verified = riskScore < 30 ? Math.random() > 0.7 : false;
    
    return {
        followers: followers.toLocaleString(),
        following: following.toLocaleString(),
        accountAge: `${accountAge} days`,
        verified: verified ? 'Yes' : 'No',
        suspiciousActivity: riskScore > 50 ? 'Detected' : 'None'
    };
}

function generateRecommendations(riskScore) {
    const recommendations = [
        { icon: 'fas fa-exclamation-triangle', text: 'Do not interact with this content' },
        { icon: 'fas fa-flag', text: 'Report this video to TikTok' },
        { icon: 'fas fa-ban', text: 'Block the account posting this content' },
        { icon: 'fas fa-shield-alt', text: 'Exercise extreme caution' },
        { icon: 'fas fa-search', text: 'Research any claims independently' },
        { icon: 'fas fa-users', text: 'Warn friends about this type of content' },
        { icon: 'fas fa-eye', text: 'Monitor your account for suspicious activity' },
        { icon: 'fas fa-lock', text: 'Review your privacy settings' }
    ];
    
    if (riskScore > 70) {
        return recommendations.slice(0, 4);
    } else if (riskScore > 40) {
        return recommendations.slice(0, 3);
    } else {
        return [{ icon: 'fas fa-check-circle', text: 'Content appears safe, but remain vigilant' }];
    }
}

function displayResults(analysis) {
    // Update risk score
    const riskScoreElement = document.getElementById('riskScoreValue');
    const riskStatusElement = document.getElementById('riskStatus');
    const riskScoreContainer = document.querySelector('.risk-score');
    
    if (riskScoreElement && riskStatusElement && riskScoreContainer) {
        riskScoreElement.textContent = analysis.riskScore;
        
        // Update risk status and styling
        if (analysis.riskScore <= 30) {
            riskStatusElement.textContent = 'Low Risk';
            riskScoreContainer.className = 'risk-score risk-score--low';
            riskScoreContainer.style.setProperty('--score-color', 'var(--color-success)');
        } else if (analysis.riskScore <= 70) {
            riskStatusElement.textContent = 'Medium Risk';
            riskScoreContainer.className = 'risk-score risk-score--medium';
            riskScoreContainer.style.setProperty('--score-color', 'var(--color-warning)');
        } else {
            riskStatusElement.textContent = 'High Risk';
            riskScoreContainer.className = 'risk-score risk-score--high';
            riskScoreContainer.style.setProperty('--score-color', 'var(--color-error)');
        }
        
        riskScoreContainer.style.setProperty('--score-percentage', `${analysis.riskScore}%`);
    }
    
    // Update indicators list
    const indicatorsList = document.getElementById('indicatorsList');
    if (indicatorsList) {
        indicatorsList.innerHTML = '';
        
        if (analysis.indicators.length === 0) {
            indicatorsList.innerHTML = '<p style="color: var(--color-text-secondary); font-style: italic;">No fraud indicators detected</p>';
        } else {
            analysis.indicators.forEach(indicator => {
                const indicatorElement = createIndicatorElement(indicator);
                indicatorsList.appendChild(indicatorElement);
            });
        }
    }
    
    // Update account analysis
    const accountInfo = document.getElementById('accountInfo');
    if (accountInfo) {
        accountInfo.innerHTML = '';
        
        Object.entries(analysis.account).forEach(([key, value]) => {
            const item = document.createElement('div');
            item.className = 'account-info__item';
            item.innerHTML = `
                <span class="account-info__label">${formatAccountLabel(key)}</span>
                <span class="account-info__value">${value}</span>
            `;
            accountInfo.appendChild(item);
        });
    }
    
    // Update recommendations
    const recommendationsList = document.getElementById('recommendationsList');
    if (recommendationsList) {
        recommendationsList.innerHTML = '';
        
        analysis.recommendations.forEach(recommendation => {
            const recElement = document.createElement('div');
            recElement.className = 'recommendation-item';
            recElement.innerHTML = `
                <i class="${recommendation.icon}"></i>
                <span class="recommendation-item__text">${recommendation.text}</span>
            `;
            recommendationsList.appendChild(recElement);
        });
    }
}

function createIndicatorElement(indicator) {
    const element = document.createElement('div');
    element.className = 'indicator-item';
    element.innerHTML = `
        <div class="indicator-item__risk indicator-item__risk--${indicator.riskLevel}"></div>
        <span class="indicator-item__text">${indicator.indicator}</span>
    `;
    
    element.addEventListener('click', () => {
        showIndicatorModal(indicator);
    });
    
    return element;
}

function formatAccountLabel(key) {
    const labels = {
        followers: 'Followers',
        following: 'Following',
        accountAge: 'Account Age',
        verified: 'Verified',
        suspiciousActivity: 'Suspicious Activity'
    };
    return labels[key] || key;
}

// Database functionality
function initializeDatabase() {
    populateDatabase();
    setupDatabaseFilters();
}

function populateDatabase() {
    const databaseContent = document.getElementById('databaseContent');
    if (!databaseContent) return;
    
    const allIndicators = [
        ...fraudData.fraudIndicators.videoContent.map(i => ({...i, category: 'Video Content'})),
        ...fraudData.fraudIndicators.accountBehavior.map(i => ({...i, category: 'Account Behavior'})),
        ...fraudData.fraudIndicators.behavioralPatterns.map(i => ({...i, category: 'Behavioral Patterns'}))
    ];
    
    databaseContent.innerHTML = '';
    
    allIndicators.forEach(indicator => {
        const card = createIndicatorCard(indicator);
        databaseContent.appendChild(card);
    });
}

function createIndicatorCard(indicator) {
    const card = document.createElement('div');
    card.className = 'indicator-card';
    card.dataset.category = indicator.category.toLowerCase().replace(' ', '');
    card.dataset.risk = indicator.riskLevel;
    
    card.innerHTML = `
        <div class="indicator-card__header">
            <div class="indicator-card__risk indicator-item__risk--${indicator.riskLevel}"></div>
            <h4 class="indicator-card__title">${indicator.indicator}</h4>
        </div>
        <p class="indicator-card__description">${indicator.description}</p>
        <span class="indicator-card__category">${indicator.category}</span>
    `;
    
    card.addEventListener('click', () => {
        showIndicatorModal(indicator);
    });
    
    return card;
}

function setupDatabaseFilters() {
    const categoryFilter = document.getElementById('categoryFilter');
    const riskFilter = document.getElementById('riskFilter');
    const searchFilter = document.getElementById('searchFilter');
    
    [categoryFilter, riskFilter, searchFilter].forEach(filter => {
        if (filter) {
            filter.addEventListener('change', filterDatabase);
            filter.addEventListener('input', filterDatabase);
        }
    });
}

function filterDatabase() {
    const categoryFilter = document.getElementById('categoryFilter');
    const riskFilter = document.getElementById('riskFilter');
    const searchFilter = document.getElementById('searchFilter');
    
    const categoryValue = categoryFilter ? categoryFilter.value : '';
    const riskValue = riskFilter ? riskFilter.value : '';
    const searchValue = searchFilter ? searchFilter.value.toLowerCase() : '';
    
    const cards = document.querySelectorAll('.indicator-card');
    
    cards.forEach(card => {
        const matchesCategory = !categoryValue || card.dataset.category.includes(categoryValue.toLowerCase());
        const matchesRisk = !riskValue || card.dataset.risk === riskValue;
        const matchesSearch = !searchValue || 
            card.textContent.toLowerCase().includes(searchValue);
        
        if (matchesCategory && matchesRisk && matchesSearch) {
            card.style.display = 'block';
        } else {
            card.style.display = 'none';
        }
    });
}

// Education functionality
function initializeEducation() {
    populateScamTypes();
    populateSafetyTips();
}

function populateScamTypes() {
    const scamTypesGrid = document.getElementById('scamTypesGrid');
    if (!scamTypesGrid) return;
    
    fraudData.scamTypes.forEach(scamType => {
        const card = document.createElement('div');
        card.className = 'scam-type-card';
        card.innerHTML = `
            <h4 class="scam-type-card__title">${scamType.type}</h4>
            <p class="scam-type-card__description">${scamType.description}</p>
            <span class="scam-type-card__prevalence">Prevalence: ${scamType.prevalence}</span>
        `;
        scamTypesGrid.appendChild(card);
    });
}

function populateSafetyTips() {
    const safetyTipsList = document.getElementById('safetyTipsList');
    if (!safetyTipsList) return;
    
    fraudData.safetyTips.forEach(tip => {
        const tipElement = document.createElement('div');
        tipElement.className = 'tip-item';
        tipElement.innerHTML = `
            <i class="fas fa-check-circle"></i>
            <span class="tip-item__text">${tip}</span>
        `;
        safetyTipsList.appendChild(tipElement);
    });
}

// Reports functionality
function initializeReports() {
    updateStatistics();
    populateRecentScans();
}

function updateStatistics() {
    const totalScans = fraudData.recentScans.length + Math.floor(Math.random() * 1000) + 500;
    const threatsDetected = fraudData.recentScans.filter(scan => scan.riskScore > 50).length + Math.floor(Math.random() * 200) + 100;
    const safeContent = totalScans - threatsDetected;
    
    const totalScansEl = document.getElementById('totalScans');
    const threatsDetectedEl = document.getElementById('threatsDetected');
    const safeContentEl = document.getElementById('safeContent');
    
    if (totalScansEl) totalScansEl.textContent = totalScans.toLocaleString();
    if (threatsDetectedEl) threatsDetectedEl.textContent = threatsDetected.toLocaleString();
    if (safeContentEl) safeContentEl.textContent = safeContent.toLocaleString();
}

function initializeFraudChart() {
    const ctx = document.getElementById('fraudChart');
    if (!ctx) {
        console.error('Fraud chart canvas not found');
        return;
    }
    
    if (fraudChart) {
        fraudChart.destroy();
    }
    
    try {
        fraudChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: fraudData.scamTypes.map(type => type.type),
                datasets: [{
                    data: fraudData.scamTypes.map(type => parseInt(type.prevalence)),
                    backgroundColor: [
                        '#1FB8CD',
                        '#FFC185',
                        '#B4413C',
                        '#ECEBD5',
                        '#5D878F'
                    ],
                    borderWidth: 2,
                    borderColor: '#ffffff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            usePointStyle: true
                        }
                    }
                }
            }
        });
    } catch (error) {
        console.error('Error creating fraud chart:', error);
    }
}

function populateRecentScans() {
    const recentScansTable = document.getElementById('recentScansTable');
    if (!recentScansTable) return;
    
    recentScansTable.innerHTML = '';
    
    fraudData.recentScans.forEach(scan => {
        const row = document.createElement('div');
        row.className = 'scan-row';
        
        const riskClass = scan.riskScore <= 30 ? 'low' : scan.riskScore <= 70 ? 'medium' : 'high';
        const timeAgo = formatTimeAgo(new Date(scan.timestamp));
        
        row.innerHTML = `
            <div class="scan-row__url">${scan.url}</div>
            <div class="scan-row__score scan-row__score--${riskClass}">${scan.riskScore}</div>
            <div class="scan-row__time">${timeAgo}</div>
            <div class="scan-row__threat">${scan.primaryThreat}</div>
        `;
        
        recentScansTable.appendChild(row);
    });
}

function formatTimeAgo(date) {
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMins / 60);
    
    if (diffMins < 60) {
        return `${diffMins}m ago`;
    } else if (diffHours < 24) {
        return `${diffHours}h ago`;
    } else {
        return `${Math.floor(diffHours / 24)}d ago`;
    }
}

// Modal functionality
function initializeModal() {
    const modal = document.getElementById('indicatorModal');
    const closeModalBtn = document.getElementById('closeModal');
    
    if (closeModalBtn) {
        closeModalBtn.addEventListener('click', hideModal);
    }
    
    if (modal) {
        modal.addEventListener('click', function(e) {
            if (e.target === modal || e.target.classList.contains('modal__backdrop')) {
                hideModal();
            }
        });
    }
    
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            hideModal();
        }
    });
}

function showIndicatorModal(indicator) {
    const modal = document.getElementById('indicatorModal');
    const modalTitle = document.getElementById('modalTitle');
    const modalBody = document.getElementById('modalBody');
    
    if (!modal || !modalTitle || !modalBody) return;
    
    modalTitle.textContent = indicator.indicator;
    
    modalBody.innerHTML = `
        <div style="margin-bottom: var(--space-16);">
            <span class="status status--${indicator.riskLevel === 'high' ? 'error' : indicator.riskLevel === 'medium' ? 'warning' : 'info'}">
                ${indicator.riskLevel.toUpperCase()} RISK
            </span>
        </div>
        <p style="font-size: var(--font-size-lg); line-height: var(--line-height-normal); margin-bottom: var(--space-20);">
            ${indicator.description}
        </p>
        <div style="padding: var(--space-16); background: var(--color-bg-1); border-radius: var(--radius-base); border-left: 4px solid var(--color-primary);">
            <h4 style="margin-bottom: var(--space-8); color: var(--color-text);">What to do if you encounter this:</h4>
            <ul style="margin: 0; padding-left: var(--space-20); color: var(--color-text);">
                <li>Report the content immediately</li>
                <li>Do not engage with the content</li>
                <li>Block the account if necessary</li>
                <li>Warn others about this type of scam</li>
            </ul>
        </div>
    `;
    
    modal.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
}

function hideModal() {
    const modal = document.getElementById('indicatorModal');
    if (modal) {
        modal.classList.add('hidden');
        document.body.style.overflow = '';
    }
}