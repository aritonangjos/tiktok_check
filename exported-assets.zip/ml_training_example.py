
# TikTok Fraud Detection - Machine Learning Training Example
# This code demonstrates how to use the synthetic dataset for ML model training

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.feature_extraction.text import TfidfVectorizer
import joblib

# Load the dataset
print("Loading TikTok fraud detection dataset...")
df = pd.read_csv('tiktok_fraud_dataset_100k.csv')

# Data preprocessing
def preprocess_data(df):
    """Preprocess the dataset for machine learning"""

    # Create a copy to avoid modifying original data
    data = df.copy()

    # Handle missing values
    data = data.fillna(0)

    # Feature engineering
    data['has_fraud_indicators'] = (data['fraud_indicators'] != '').astype(int)
    data['indicator_count'] = data['fraud_indicators'].str.count('|') + 1
    data['indicator_count'] = data['indicator_count'].where(data['has_fraud_indicators'] == 1, 0)

    data['title_length'] = data['title'].str.len()
    data['has_urgent_keywords'] = data['title'].str.contains('urgent|now|act fast|limited time|hurry', case=False, na=False).astype(int)
    data['has_money_keywords'] = data['title'].str.contains('money|cash|profit|earn|$|free', case=False, na=False).astype(int)

    # Calculate engagement ratios
    data['likes_ratio'] = data['likes'] / (data['view_count'] + 1)
    data['comments_ratio'] = data['comments'] / (data['view_count'] + 1)
    data['shares_ratio'] = data['shares'] / (data['view_count'] + 1)

    # Account features
    data['account_age_weeks'] = data['account_age_days'] / 7
    data['posts_per_day'] = 1 / (data['account_age_days'] + 1)  # Simplified assumption

    return data

# Prepare features for ML
def prepare_features(data):
    """Prepare feature matrices for machine learning"""

    # Numerical features
    numerical_features = [
        'followers', 'following', 'follower_following_ratio', 'account_age_days',
        'duration_seconds', 'view_count', 'likes', 'shares', 'comments',
        'engagement_rate', 'title_length', 'indicator_count',
        'likes_ratio', 'comments_ratio', 'shares_ratio', 'account_age_weeks'
    ]

    # Categorical features
    categorical_features = [
        'category', 'risk_level', 'audio_language', 'location_country'
    ]

    # Binary features
    binary_features = [
        'is_verified', 'has_external_links', 'has_fraud_indicators',
        'has_urgent_keywords', 'has_money_keywords'
    ]

    # Prepare numerical features
    X_numerical = data[numerical_features].fillna(0)
    scaler = StandardScaler()
    X_numerical_scaled = scaler.fit_transform(X_numerical)

    # Prepare categorical features
    X_categorical = data[categorical_features].copy()
    label_encoders = {}
    for feature in categorical_features:
        le = LabelEncoder()
        X_categorical[feature] = le.fit_transform(X_categorical[feature].astype(str))
        label_encoders[feature] = le

    # Prepare binary features
    X_binary = data[binary_features].astype(int)

    # Prepare text features (TF-IDF on titles)
    tfidf = TfidfVectorizer(max_features=100, stop_words='english')
    X_text = tfidf.fit_transform(data['title'].fillna(''))

    # Combine all features
    X_combined = np.hstack([
        X_numerical_scaled,
        X_categorical.values,
        X_binary.values,
        X_text.toarray()
    ])

    feature_names = (numerical_features + categorical_features + 
                    binary_features + [f'title_tfidf_{i}' for i in range(100)])

    return X_combined, feature_names, scaler, label_encoders, tfidf

# Train the model
def train_fraud_detection_model(data):
    """Train a Random Forest model for fraud detection"""

    # Prepare features
    X, feature_names, scaler, label_encoders, tfidf = prepare_features(data)
    y = data['is_fraud'].astype(int)

    # Split the data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    print(f"Training set size: {X_train.shape[0]:,} samples")
    print(f"Test set size: {X_test.shape[0]:,} samples")
    print(f"Number of features: {X_train.shape[1]:,}")

    # Train Random Forest model
    rf_model = RandomForestClassifier(
        n_estimators=100,
        max_depth=10,
        min_samples_split=5,
        min_samples_leaf=2,
        random_state=42,
        n_jobs=-1
    )

    print("\nTraining Random Forest model...")
    rf_model.fit(X_train, y_train)

    # Make predictions
    y_pred = rf_model.predict(X_test)
    y_pred_proba = rf_model.predict_proba(X_test)[:, 1]

    # Evaluate the model
    print("\n=== MODEL EVALUATION ===")
    print("Classification Report:")
    print(classification_report(y_test, y_pred))

    print(f"\nROC AUC Score: {roc_auc_score(y_test, y_pred_proba):.4f}")

    # Feature importance
    feature_importance = pd.DataFrame({
        'feature': feature_names,
        'importance': rf_model.feature_importances_
    }).sort_values('importance', ascending=False)

    print("\nTop 15 Most Important Features:")
    for i, row in feature_importance.head(15).iterrows():
        print(f"  {row['feature']}: {row['importance']:.4f}")

    # Save the model and preprocessors
    model_artifacts = {
        'model': rf_model,
        'scaler': scaler,
        'label_encoders': label_encoders,
        'tfidf': tfidf,
        'feature_names': feature_names
    }

    joblib.dump(model_artifacts, 'tiktok_fraud_detection_model.pkl')
    print("\nModel saved as: tiktok_fraud_detection_model.pkl")

    return rf_model, model_artifacts

# Usage example
if __name__ == "__main__":
    # Load and preprocess data
    data = preprocess_data(df)

    # Train the model
    model, artifacts = train_fraud_detection_model(data)

    print("\n=== TRAINING COMPLETE ===")
    print("The model is now ready for fraud detection!")
    print("Use the saved model to make predictions on new TikTok videos.")

# Function to predict fraud for new videos
def predict_fraud(video_data, model_artifacts):
    """Predict fraud probability for new video data"""

    # Preprocess the new data
    processed_data = preprocess_data(video_data)

    # Extract features
    X, _, _, _, _ = prepare_features(processed_data)

    # Make prediction
    model = model_artifacts['model']
    fraud_probability = model.predict_proba(X)[:, 1]

    return fraud_probability

# Example usage for single prediction
def predict_single_video(url, title, username, followers, engagement_rate):
    """Example function to predict fraud for a single video"""

    # Create sample data structure
    video_data = pd.DataFrame([{
        'video_url': url,
        'title': title,
        'username': username,
        'followers': followers,
        'engagement_rate': engagement_rate,
        'category': 'unknown',  # Would need classification
        'account_age_days': 100,  # Would need to be retrieved
        'is_verified': False,
        'has_external_links': 'http' in title.lower(),
        # ... other required features
    }])

    # Load model
    model_artifacts = joblib.load('tiktok_fraud_detection_model.pkl')

    # Predict
    fraud_prob = predict_fraud(video_data, model_artifacts)

    return fraud_prob[0]
