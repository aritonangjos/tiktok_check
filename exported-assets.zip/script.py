import pandas as pd
import numpy as np
import random
from datetime import datetime, timedelta
import uuid

# Set random seed for reproducibility
np.random.seed(42)
random.seed(42)

print("Creating synthetic TikTok fraud detection dataset with 100,000 rows...")
print("This is synthetic data for development/testing purposes only.\n")

# Define data generation parameters
n_rows = 100000

# Video URL patterns
url_patterns = [
    "https://www.tiktok.com/@{}/video/{}",
    "https://tiktok.com/@{}/video/{}",
    "https://vm.tiktok.com/{}",
    "https://www.tiktok.com/t/{}"
]

# Username patterns for different risk levels
high_risk_usernames = [
    "crypto_king_{}", "easy_money_{}", "giveaway_girl_{}", "investment_guru_{}",
    "quick_cash_{}", "bitcoin_master_{}", "free_stuff_{}", "money_maker_{}",
    "rich_life_{}", "millionaire_{}", "cash_flow_{}", "profit_pro_{}"
]

medium_risk_usernames = [
    "deal_finder_{}", "shopping_queen_{}", "product_review_{}", "discount_hunter_{}",
    "lifestyle_tips_{}", "beauty_hack_{}", "fitness_coach_{}", "travel_deals_{}"
]

low_risk_usernames = [
    "daily_vlogs_{}", "art_creator_{}", "music_lover_{}", "dance_moves_{}",
    "cooking_tips_{}", "pet_videos_{}", "nature_walks_{}", "family_fun_{}"
]

# Content categories and their fraud likelihood
content_categories = {
    "investment": {"fraud_prob": 0.8, "keywords": ["crypto", "bitcoin", "trading", "investment", "profit", "money"]},
    "giveaway": {"fraud_prob": 0.9, "keywords": ["free", "giveaway", "win", "prize", "gift", "lucky"]},
    "product": {"fraud_prob": 0.4, "keywords": ["buy", "shop", "deal", "discount", "sale", "product"]},
    "romance": {"fraud_prob": 0.7, "keywords": ["love", "relationship", "dating", "lonely", "heart", "romance"]},
    "phishing": {"fraud_prob": 0.85, "keywords": ["verify", "account", "login", "password", "urgent", "suspended"]},
    "entertainment": {"fraud_prob": 0.1, "keywords": ["funny", "dance", "music", "comedy", "art", "creative"]},
    "education": {"fraud_prob": 0.05, "keywords": ["learn", "tutorial", "tips", "howto", "guide", "education"]},
    "lifestyle": {"fraud_prob": 0.2, "keywords": ["daily", "life", "routine", "vlog", "family", "friends"]}
}

def generate_username(risk_level):
    """Generate username based on risk level"""
    if risk_level == "high":
        base = random.choice(high_risk_usernames)
    elif risk_level == "medium":
        base = random.choice(medium_risk_usernames)
    else:
        base = random.choice(low_risk_usernames)
    
    return base.format(random.randint(1, 9999))

def generate_video_url(username):
    """Generate realistic TikTok video URL"""
    pattern = random.choice(url_patterns)
    if "@{}" in pattern:
        video_id = random.randint(7000000000000000000, 7999999999999999999)
        return pattern.format(username, video_id)
    else:
        short_id = ''.join(random.choices('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789', k=9))
        return pattern.format(short_id)

def generate_content_data(category):
    """Generate content characteristics based on category"""
    cat_data = content_categories[category]
    
    # Title generation
    keywords = cat_data["keywords"]
    title_templates = {
        "investment": [
            "🚀 How I made ${} in {} days with this strategy!",
            "💰 SECRET crypto method - turn ${} into ${}!",
            "📈 Investment opportunity - guaranteed {}% returns",
            "💎 This Bitcoin strategy changed my life!"
        ],
        "giveaway": [
            "🎁 FREE ${} GIVEAWAY! Requirements in comments",
            "🎉 MASSIVE GIVEAWAY - ${} worth of prizes!",
            "🔥 Last chance to win {}! Act fast!",
            "⭐ You could be the lucky winner of ${}"
        ],
        "product": [
            "😍 This {} changed everything! Link in bio",
            "🛍️ AMAZING {} deal - {}% OFF today only!",
            "⚡ Best {} I've ever used - honest review",
            "🔥 {} hack that actually works!"
        ],
        "romance": [
            "💕 Looking for someone special...",
            "❤️ Why I'm still single at {}",
            "💔 Heartbreak story - need your advice",
            "🌹 Ready to find my soulmate"
        ],
        "phishing": [
            "🚨 URGENT: Your TikTok account will be suspended!",
            "⚠️ Verify your account NOW to avoid deletion",
            "🔒 New security update - verify immediately",
            "❗ Account verification required - click link"
        ],
        "entertainment": [
            "😂 This made my day! Hope it makes yours too",
            "🎵 Dancing to my favorite song",
            "🎭 Trying this viral trend",
            "✨ Just being creative today"
        ],
        "education": [
            "📚 How to {} - step by step tutorial",
            "🎓 Learning {} - sharing my progress",
            "💡 {} tips that actually work",
            "🔍 Everything you need to know about {}"
        ],
        "lifestyle": [
            "☀️ My morning routine",
            "🏠 Day in my life",
            "👨‍👩‍👧‍👦 Family time is the best time",
            "🌟 Grateful for this beautiful day"
        ]
    }
    
    if category in title_templates:
        template = random.choice(title_templates[category])
        if "{}" in template:
            if category == "investment":
                amounts = [500, 1000, 2500, 5000, 10000, 25000]
                days = [7, 14, 30, 60]
                percentages = [200, 300, 500, 1000]
                template = template.format(
                    random.choice(amounts),
                    random.choice(days) if "days" in template else random.choice(percentages)
                )
            elif category == "giveaway":
                amounts = [100, 500, 1000, 2500, 5000]
                prizes = ["iPhone", "MacBook", "Cash", "Gift Cards"]
                template = template.format(
                    random.choice(amounts) if "$" in template else random.choice(prizes)
                )
            elif category == "product":
                products = ["skincare", "gadget", "clothing", "supplement"]
                discounts = [20, 30, 50, 70]
                template = template.format(
                    random.choice(products),
                    random.choice(discounts) if "%" in template else ""
                ).replace("  ", " ")
            elif category == "romance":
                ages = [22, 25, 28, 30, 35]
                template = template.format(random.choice(ages))
            else:
                skills = ["cook", "draw", "code", "dance", "sing"]
                template = template.format(random.choice(skills))
        title = template
    else:
        title = f"Check out this {category} content!"
    
    return title, random.choice(keywords)

# Generate the main dataset
print("Generating video records...")
data = []

for i in range(n_rows):
    if i % 10000 == 0:
        print(f"Generated {i:,} records...")
    
    # Determine content category and fraud likelihood
    category = np.random.choice(list(content_categories.keys()), 
                               p=[0.15, 0.20, 0.25, 0.08, 0.07, 0.15, 0.05, 0.05])
    is_fraud = np.random.random() < content_categories[category]["fraud_prob"]
    
    # Determine risk level based on fraud status
    if is_fraud:
        risk_level = np.random.choice(["high", "medium"], p=[0.7, 0.3])
        risk_score = np.random.normal(75, 15) if risk_level == "high" else np.random.normal(55, 10)
    else:
        risk_level = np.random.choice(["low", "medium"], p=[0.8, 0.2])
        risk_score = np.random.normal(20, 10) if risk_level == "low" else np.random.normal(35, 8)
    
    risk_score = max(0, min(100, risk_score))  # Clamp between 0-100
    
    # Generate user data
    username = generate_username(risk_level)
    video_url = generate_video_url(username)
    title, primary_keyword = generate_content_data(category)
    
    # Account characteristics
    if risk_level == "high":
        followers = np.random.lognormal(6, 2)  # Lower follower count for fraud accounts
        following = np.random.lognormal(8, 1)  # High following count
        account_age_days = np.random.exponential(90)  # Newer accounts
        is_verified = np.random.random() < 0.02  # Very rarely verified
    elif risk_level == "medium":
        followers = np.random.lognormal(8, 2)
        following = np.random.lognormal(7, 1)
        account_age_days = np.random.exponential(200)
        is_verified = np.random.random() < 0.05
    else:
        followers = np.random.lognormal(9, 2)  # Higher follower count for legit accounts
        following = np.random.lognormal(6, 1)  # Reasonable following count
        account_age_days = np.random.exponential(500)  # Older accounts
        is_verified = np.random.random() < 0.1
    
    followers = max(1, int(followers))
    following = max(0, int(following))
    account_age_days = max(1, int(account_age_days))
    
    # Video characteristics
    duration = np.random.choice([15, 30, 60, 180], p=[0.4, 0.3, 0.2, 0.1])
    view_count = max(1, int(np.random.lognormal(8, 3)))
    likes = max(0, int(view_count * np.random.beta(2, 20)))
    shares = max(0, int(likes * np.random.beta(1, 50)))
    comments = max(0, int(likes * np.random.beta(1, 30)))
    
    # Engagement rate
    total_engagements = likes + shares + comments
    engagement_rate = (total_engagements / view_count) * 100 if view_count > 0 else 0
    
    # Upload timestamp (last 90 days)
    upload_date = datetime.now() - timedelta(days=np.random.randint(1, 91))
    
    # Fraud indicators
    fraud_indicators = []
    if is_fraud:
        possible_indicators = [
            "Promises of easy money",
            "Urgent language",
            "External links",
            "Requests personal info",
            "Fake giveaway",
            "Investment scheme",
            "Celebrity impersonation",
            "Suspicious engagement",
            "New account",
            "Cryptocurrency promotion"
        ]
        num_indicators = np.random.poisson(2.5) + 1
        fraud_indicators = random.sample(possible_indicators, 
                                       min(num_indicators, len(possible_indicators)))
    
    # Create record
    record = {
        'video_id': str(uuid.uuid4()),
        'video_url': video_url,
        'username': username,
        'title': title,
        'category': category,
        'primary_keyword': primary_keyword,
        'is_fraud': is_fraud,
        'risk_score': round(risk_score, 2),
        'risk_level': risk_level,
        'fraud_indicators': '|'.join(fraud_indicators) if fraud_indicators else '',
        'followers': followers,
        'following': following,
        'follower_following_ratio': round(followers / max(following, 1), 2),
        'account_age_days': account_age_days,
        'is_verified': is_verified,
        'duration_seconds': duration,
        'view_count': view_count,
        'likes': likes,
        'shares': shares,
        'comments': comments,
        'engagement_rate': round(engagement_rate, 4),
        'upload_date': upload_date.strftime('%Y-%m-%d %H:%M:%S'),
        'has_external_links': np.random.random() < (0.7 if is_fraud else 0.1),
        'audio_language': np.random.choice(['en', 'es', 'fr', 'de', 'it', 'pt', 'zh', 'ja', 'ko'], 
                                         p=[0.4, 0.15, 0.1, 0.08, 0.05, 0.05, 0.07, 0.05, 0.05]),
        'location_country': np.random.choice(['US', 'UK', 'CA', 'AU', 'DE', 'FR', 'BR', 'MX', 'JP', 'KR', 'IN', 'Other'], 
                                           p=[0.25, 0.08, 0.06, 0.04, 0.05, 0.04, 0.08, 0.06, 0.04, 0.03, 0.12, 0.15]),
    }
    
    data.append(record)

# Convert to DataFrame
df = pd.DataFrame(data)

print(f"\nDataset generation complete!")
print(f"Total records: {len(df):,}")
print(f"Fraudulent videos: {df['is_fraud'].sum():,} ({df['is_fraud'].mean()*100:.1f}%)")
print(f"Legitimate videos: {(~df['is_fraud']).sum():,} ({(~df['is_fraud']).mean()*100:.1f}%)")

# Display sample statistics
print(f"\n=== SAMPLE STATISTICS ===")
print(f"Risk Score Distribution:")
print(f"  High Risk (71-100): {((df['risk_score'] >= 71).sum() / len(df) * 100):.1f}%")
print(f"  Medium Risk (31-70): {(((df['risk_score'] >= 31) & (df['risk_score'] < 71)).sum() / len(df) * 100):.1f}%")
print(f"  Low Risk (0-30): {((df['risk_score'] < 31).sum() / len(df) * 100):.1f}%")

print(f"\nContent Categories:")
for category in df['category'].value_counts().index:
    count = df['category'].value_counts()[category]
    fraud_rate = df[df['category'] == category]['is_fraud'].mean() * 100
    print(f"  {category.title()}: {count:,} videos ({fraud_rate:.1f}% fraud rate)")

print(f"\nAccount Characteristics:")
print(f"  Verified accounts: {df['is_verified'].sum():,} ({df['is_verified'].mean()*100:.1f}%)")
print(f"  Average followers: {df['followers'].median():,.0f} (median)")
print(f"  Average account age: {df['account_age_days'].median():.0f} days (median)")

# Save to CSV
filename = "tiktok_fraud_dataset_100k.csv"
df.to_csv(filename, index=False)
print(f"\nDataset saved to: {filename}")
print(f"File size: {df.memory_usage(deep=True).sum() / 1024 / 1024:.1f} MB")

# Display first few rows
print(f"\n=== SAMPLE DATA (First 5 rows) ===")
pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)
print(df[['video_url', 'username', 'title', 'category', 'is_fraud', 'risk_score', 'followers', 'view_count']].head())