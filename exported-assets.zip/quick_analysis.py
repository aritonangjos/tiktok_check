#!/usr/bin/env python3
"""
Quick analysis script for the TikTok fraud detection dataset
Run this script to get basic insights about the dataset
"""

import pandas as pd
import numpy as np

def analyze_dataset():
    """Perform basic analysis of the dataset"""

    print("Loading TikTok fraud detection dataset...")
    try:
        df = pd.read_csv('tiktok_fraud_dataset_100k.csv')
    except FileNotFoundError:
        print("Error: tiktok_fraud_dataset_100k.csv not found!")
        return

    print(f"Dataset loaded successfully: {df.shape[0]:,} rows, {df.shape[1]} columns")

    # Basic statistics
    print("\n=== BASIC STATISTICS ===")
    print(f"Total videos: {len(df):,}")
    print(f"Fraudulent videos: {df['is_fraud'].sum():,} ({df['is_fraud'].mean()*100:.1f}%)")
    print(f"Legitimate videos: {(~df['is_fraud']).sum():,} ({(~df['is_fraud']).mean()*100:.1f}%)")
    print(f"Date range: {df['upload_date'].min()} to {df['upload_date'].max()}")

    # Category breakdown
    print("\n=== FRAUD RATES BY CATEGORY ===")
    category_stats = df.groupby('category').agg({
        'is_fraud': ['count', 'sum', 'mean']
    }).round(3)
    category_stats.columns = ['Total', 'Fraud', 'Rate']
    category_stats = category_stats.sort_values('Rate', ascending=False)

    for category, row in category_stats.iterrows():
        print(f"{category.capitalize():12}: {row['Total']:6,} videos | {row['Fraud']:6,} fraud | {row['Rate']*100:5.1f}% rate")

    # Risk score distribution
    print("\n=== RISK SCORE DISTRIBUTION ===")
    print(f"Low risk (0-30):     {(df['risk_score'] <= 30).sum():6,} videos ({(df['risk_score'] <= 30).mean()*100:.1f}%)")
    print(f"Medium risk (31-70): {((df['risk_score'] > 30) & (df['risk_score'] <= 70)).sum():6,} videos ({((df['risk_score'] > 30) & (df['risk_score'] <= 70)).mean()*100:.1f}%)")
    print(f"High risk (71-100):  {(df['risk_score'] > 70).sum():6,} videos ({(df['risk_score'] > 70).mean()*100:.1f}%)")

    # Account characteristics
    print("\n=== ACCOUNT CHARACTERISTICS ===")
    fraud_accounts = df[df['is_fraud'] == True]
    legit_accounts = df[df['is_fraud'] == False]

    print("Fraud accounts:")
    print(f"  Median followers: {fraud_accounts['followers'].median():,.0f}")
    print(f"  Median account age: {fraud_accounts['account_age_days'].median():.0f} days")
    print(f"  Verification rate: {fraud_accounts['is_verified'].mean()*100:.1f}%")

    print("Legitimate accounts:")
    print(f"  Median followers: {legit_accounts['followers'].median():,.0f}")
    print(f"  Median account age: {legit_accounts['account_age_days'].median():.0f} days")
    print(f"  Verification rate: {legit_accounts['is_verified'].mean()*100:.1f}%")

    # Most common fraud indicators
    print("\n=== TOP FRAUD INDICATORS ===")
    all_indicators = []
    for indicators_str in fraud_accounts['fraud_indicators'].dropna():
        if indicators_str:
            all_indicators.extend(indicators_str.split('|'))

    from collections import Counter
    top_indicators = Counter(all_indicators).most_common(5)

    for indicator, count in top_indicators:
        percentage = (count / len(fraud_accounts)) * 100
        print(f"{indicator:25}: {count:6,} occurrences ({percentage:.1f}%)")

    print("\n=== ANALYSIS COMPLETE ===")
    print("Dataset is ready for machine learning and fraud detection research!")

if __name__ == "__main__":
    analyze_dataset()
