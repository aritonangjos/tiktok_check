# Create example ML training code and documentation

ml_example_code = '''
# TikTok Fraud Detection - Machine Learning Training Example
# This code demonstrates how to use the synthetic dataset for ML model training

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.feature_extraction.text import TfidfVectorizer
import joblib

# Load the dataset
print("Loading TikTok fraud detection dataset...")
df = pd.read_csv('tiktok_fraud_dataset_100k.csv')

# Data preprocessing
def preprocess_data(df):
    """Preprocess the dataset for machine learning"""
    
    # Create a copy to avoid modifying original data
    data = df.copy()
    
    # Handle missing values
    data = data.fillna(0)
    
    # Feature engineering
    data['has_fraud_indicators'] = (data['fraud_indicators'] != '').astype(int)
    data['indicator_count'] = data['fraud_indicators'].str.count('|') + 1
    data['indicator_count'] = data['indicator_count'].where(data['has_fraud_indicators'] == 1, 0)
    
    data['title_length'] = data['title'].str.len()
    data['has_urgent_keywords'] = data['title'].str.contains('urgent|now|act fast|limited time|hurry', case=False, na=False).astype(int)
    data['has_money_keywords'] = data['title'].str.contains('money|cash|profit|earn|$|free', case=False, na=False).astype(int)
    
    # Calculate engagement ratios
    data['likes_ratio'] = data['likes'] / (data['view_count'] + 1)
    data['comments_ratio'] = data['comments'] / (data['view_count'] + 1)
    data['shares_ratio'] = data['shares'] / (data['view_count'] + 1)
    
    # Account features
    data['account_age_weeks'] = data['account_age_days'] / 7
    data['posts_per_day'] = 1 / (data['account_age_days'] + 1)  # Simplified assumption
    
    return data

# Prepare features for ML
def prepare_features(data):
    """Prepare feature matrices for machine learning"""
    
    # Numerical features
    numerical_features = [
        'followers', 'following', 'follower_following_ratio', 'account_age_days',
        'duration_seconds', 'view_count', 'likes', 'shares', 'comments',
        'engagement_rate', 'title_length', 'indicator_count',
        'likes_ratio', 'comments_ratio', 'shares_ratio', 'account_age_weeks'
    ]
    
    # Categorical features
    categorical_features = [
        'category', 'risk_level', 'audio_language', 'location_country'
    ]
    
    # Binary features
    binary_features = [
        'is_verified', 'has_external_links', 'has_fraud_indicators',
        'has_urgent_keywords', 'has_money_keywords'
    ]
    
    # Prepare numerical features
    X_numerical = data[numerical_features].fillna(0)
    scaler = StandardScaler()
    X_numerical_scaled = scaler.fit_transform(X_numerical)
    
    # Prepare categorical features
    X_categorical = data[categorical_features].copy()
    label_encoders = {}
    for feature in categorical_features:
        le = LabelEncoder()
        X_categorical[feature] = le.fit_transform(X_categorical[feature].astype(str))
        label_encoders[feature] = le
    
    # Prepare binary features
    X_binary = data[binary_features].astype(int)
    
    # Prepare text features (TF-IDF on titles)
    tfidf = TfidfVectorizer(max_features=100, stop_words='english')
    X_text = tfidf.fit_transform(data['title'].fillna(''))
    
    # Combine all features
    X_combined = np.hstack([
        X_numerical_scaled,
        X_categorical.values,
        X_binary.values,
        X_text.toarray()
    ])
    
    feature_names = (numerical_features + categorical_features + 
                    binary_features + [f'title_tfidf_{i}' for i in range(100)])
    
    return X_combined, feature_names, scaler, label_encoders, tfidf

# Train the model
def train_fraud_detection_model(data):
    """Train a Random Forest model for fraud detection"""
    
    # Prepare features
    X, feature_names, scaler, label_encoders, tfidf = prepare_features(data)
    y = data['is_fraud'].astype(int)
    
    # Split the data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    
    print(f"Training set size: {X_train.shape[0]:,} samples")
    print(f"Test set size: {X_test.shape[0]:,} samples")
    print(f"Number of features: {X_train.shape[1]:,}")
    
    # Train Random Forest model
    rf_model = RandomForestClassifier(
        n_estimators=100,
        max_depth=10,
        min_samples_split=5,
        min_samples_leaf=2,
        random_state=42,
        n_jobs=-1
    )
    
    print("\\nTraining Random Forest model...")
    rf_model.fit(X_train, y_train)
    
    # Make predictions
    y_pred = rf_model.predict(X_test)
    y_pred_proba = rf_model.predict_proba(X_test)[:, 1]
    
    # Evaluate the model
    print("\\n=== MODEL EVALUATION ===")
    print("Classification Report:")
    print(classification_report(y_test, y_pred))
    
    print(f"\\nROC AUC Score: {roc_auc_score(y_test, y_pred_proba):.4f}")
    
    # Feature importance
    feature_importance = pd.DataFrame({
        'feature': feature_names,
        'importance': rf_model.feature_importances_
    }).sort_values('importance', ascending=False)
    
    print("\\nTop 15 Most Important Features:")
    for i, row in feature_importance.head(15).iterrows():
        print(f"  {row['feature']}: {row['importance']:.4f}")
    
    # Save the model and preprocessors
    model_artifacts = {
        'model': rf_model,
        'scaler': scaler,
        'label_encoders': label_encoders,
        'tfidf': tfidf,
        'feature_names': feature_names
    }
    
    joblib.dump(model_artifacts, 'tiktok_fraud_detection_model.pkl')
    print("\\nModel saved as: tiktok_fraud_detection_model.pkl")
    
    return rf_model, model_artifacts

# Usage example
if __name__ == "__main__":
    # Load and preprocess data
    data = preprocess_data(df)
    
    # Train the model
    model, artifacts = train_fraud_detection_model(data)
    
    print("\\n=== TRAINING COMPLETE ===")
    print("The model is now ready for fraud detection!")
    print("Use the saved model to make predictions on new TikTok videos.")

# Function to predict fraud for new videos
def predict_fraud(video_data, model_artifacts):
    """Predict fraud probability for new video data"""
    
    # Preprocess the new data
    processed_data = preprocess_data(video_data)
    
    # Extract features
    X, _, _, _, _ = prepare_features(processed_data)
    
    # Make prediction
    model = model_artifacts['model']
    fraud_probability = model.predict_proba(X)[:, 1]
    
    return fraud_probability

# Example usage for single prediction
def predict_single_video(url, title, username, followers, engagement_rate):
    """Example function to predict fraud for a single video"""
    
    # Create sample data structure
    video_data = pd.DataFrame([{
        'video_url': url,
        'title': title,
        'username': username,
        'followers': followers,
        'engagement_rate': engagement_rate,
        'category': 'unknown',  # Would need classification
        'account_age_days': 100,  # Would need to be retrieved
        'is_verified': False,
        'has_external_links': 'http' in title.lower(),
        # ... other required features
    }])
    
    # Load model
    model_artifacts = joblib.load('tiktok_fraud_detection_model.pkl')
    
    # Predict
    fraud_prob = predict_fraud(video_data, model_artifacts)
    
    return fraud_prob[0]
'''

# Save the ML example code
with open('ml_training_example.py', 'w') as f:
    f.write(ml_example_code)

print("=== MACHINE LEARNING TRAINING CODE CREATED ===")
print("File saved: ml_training_example.py")
print("This file contains complete example code for training a fraud detection model")

# Create data documentation
data_documentation = '''# TikTok Fraud Detection Dataset Documentation

## Overview
This synthetic dataset contains 100,000 TikTok video records designed for fraud detection research and model training. 

**Important:** This is synthetic data created for development and testing purposes only. It does not contain real TikTok data or personal information.

## Dataset Statistics
- **Total Records:** 100,000
- **Fraudulent Videos:** 54,291 (54.3%)
- **Legitimate Videos:** 45,709 (45.7%)
- **Features per Record:** 27
- **File Size:** ~101.6 MB
- **Time Period:** 90 days of synthetic activity
- **Unique Users:** 83,696

## Features Description

### Basic Information
- `video_id`: Unique identifier for each video (UUID format)
- `video_url`: Synthetic TikTok video URL
- `username`: TikTok username (synthetic)
- `title`: Video title/caption
- `upload_date`: Video upload timestamp

### Content Classification
- `category`: Content category (investment, giveaway, product, romance, phishing, entertainment, education, lifestyle)
- `primary_keyword`: Primary keyword associated with the content
- `is_fraud`: Binary target variable (True = fraud, False = legitimate)
- `risk_score`: Fraud risk score (0-100 scale)
- `risk_level`: Risk categorization (low, medium, high)
- `fraud_indicators`: Pipe-separated list of detected fraud indicators

### Account Features
- `followers`: Number of followers
- `following`: Number of accounts following
- `follower_following_ratio`: Ratio of followers to following
- `account_age_days`: Age of account in days
- `is_verified`: Verification status (Boolean)

### Engagement Metrics
- `view_count`: Number of video views
- `likes`: Number of likes
- `shares`: Number of shares
- `comments`: Number of comments
- `engagement_rate`: Overall engagement rate percentage
- `duration_seconds`: Video duration in seconds

### Additional Features
- `has_external_links`: Presence of external links (Boolean)
- `audio_language`: Audio language code
- `location_country`: Content creator's country

## Fraud Categories and Rates

| Category | Videos | Fraud Rate |
|----------|---------|------------|
| Giveaway | 20,249 | 90.0% |
| Phishing | 7,089 | 84.8% |
| Investment | 14,743 | 79.8% |
| Romance | 7,949 | 68.9% |
| Product | 25,069 | 40.1% |
| Lifestyle | 5,028 | 19.6% |
| Entertainment | 14,985 | 10.2% |
| Education | 4,888 | 5.0% |

## Common Fraud Indicators

1. **Suspicious engagement** (35.3% of fraud videos)
2. **Promises of easy money** (35.3% of fraud videos)
3. **New account** (35.1% of fraud videos)
4. **Fake giveaway** (35.0% of fraud videos)
5. **Urgent language** (35.0% of fraud videos)
6. **External links** (35.0% of fraud videos)
7. **Investment scheme** (34.9% of fraud videos)
8. **Requests personal info** (34.9% of fraud videos)
9. **Celebrity impersonation** (34.9% of fraud videos)
10. **Cryptocurrency promotion** (34.7% of fraud videos)

## Usage Examples

### Loading the Dataset
```python
import pandas as pd
df = pd.read_csv('tiktok_fraud_dataset_100k.csv')
print(f"Dataset shape: {df.shape}")
```

### Basic Analysis
```python
# Fraud distribution
fraud_rate = df['is_fraud'].mean()
print(f"Overall fraud rate: {fraud_rate:.1%}")

# Category analysis
category_fraud = df.groupby('category')['is_fraud'].mean().sort_values(ascending=False)
print("Fraud rate by category:")
print(category_fraud)
```

### Feature Engineering Examples
```python
# Create additional features
df['has_fraud_indicators'] = (df['fraud_indicators'] != '').astype(int)
df['likes_ratio'] = df['likes'] / (df['view_count'] + 1)
df['title_length'] = df['title'].str.len()
df['has_money_keywords'] = df['title'].str.contains('money|cash|free|$', case=False, na=False)
```

### Machine Learning Preparation
```python
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

# Select features
features = ['followers', 'engagement_rate', 'account_age_days', 'has_external_links']
X = df[features]
y = df['is_fraud']

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
```

## Applications

This dataset can be used for:

1. **Binary Classification**: Predict fraud vs. legitimate content
2. **Risk Scoring**: Develop risk scoring algorithms
3. **Pattern Analysis**: Identify fraud patterns and trends
4. **Feature Engineering**: Develop new fraud detection features
5. **Model Benchmarking**: Compare different ML algorithms
6. **Anomaly Detection**: Identify unusual patterns in social media content
7. **Educational Purposes**: Teaching fraud detection concepts

## File Structure

```
├── tiktok_fraud_dataset_100k.csv    # Main dataset (100K records)
├── dataset_summary.csv              # Summary statistics
├── ml_training_example.py           # ML training code example
└── README.md                        # This documentation
```

## Important Notes

- This is **synthetic data** created for development purposes
- Real TikTok data would require proper API access and privacy compliance
- The fraud patterns are based on research but may not reflect exact real-world distributions
- Always validate models on real data before production deployment
- Consider data privacy and ethical implications when working with social media data

## Citation

If using this dataset for research, please cite:
```
TikTok Fraud Detection Synthetic Dataset (2025)
Generated for fraud detection research and model development
100,000 synthetic video records with fraud indicators
```

## License

This synthetic dataset is provided for educational and research purposes only.
'''

# Save documentation
with open('dataset_documentation.md', 'w') as f:
    f.write(data_documentation)

print("\n=== DATASET DOCUMENTATION CREATED ===")
print("File saved: dataset_documentation.md")
print("Complete documentation with usage examples and feature descriptions")

# Create a simple analysis script
analysis_script = '''#!/usr/bin/env python3
"""
Quick analysis script for the TikTok fraud detection dataset
Run this script to get basic insights about the dataset
"""

import pandas as pd
import numpy as np

def analyze_dataset():
    """Perform basic analysis of the dataset"""
    
    print("Loading TikTok fraud detection dataset...")
    try:
        df = pd.read_csv('tiktok_fraud_dataset_100k.csv')
    except FileNotFoundError:
        print("Error: tiktok_fraud_dataset_100k.csv not found!")
        return
    
    print(f"Dataset loaded successfully: {df.shape[0]:,} rows, {df.shape[1]} columns")
    
    # Basic statistics
    print("\\n=== BASIC STATISTICS ===")
    print(f"Total videos: {len(df):,}")
    print(f"Fraudulent videos: {df['is_fraud'].sum():,} ({df['is_fraud'].mean()*100:.1f}%)")
    print(f"Legitimate videos: {(~df['is_fraud']).sum():,} ({(~df['is_fraud']).mean()*100:.1f}%)")
    print(f"Date range: {df['upload_date'].min()} to {df['upload_date'].max()}")
    
    # Category breakdown
    print("\\n=== FRAUD RATES BY CATEGORY ===")
    category_stats = df.groupby('category').agg({
        'is_fraud': ['count', 'sum', 'mean']
    }).round(3)
    category_stats.columns = ['Total', 'Fraud', 'Rate']
    category_stats = category_stats.sort_values('Rate', ascending=False)
    
    for category, row in category_stats.iterrows():
        print(f"{category.capitalize():12}: {row['Total']:6,} videos | {row['Fraud']:6,} fraud | {row['Rate']*100:5.1f}% rate")
    
    # Risk score distribution
    print("\\n=== RISK SCORE DISTRIBUTION ===")
    print(f"Low risk (0-30):     {(df['risk_score'] <= 30).sum():6,} videos ({(df['risk_score'] <= 30).mean()*100:.1f}%)")
    print(f"Medium risk (31-70): {((df['risk_score'] > 30) & (df['risk_score'] <= 70)).sum():6,} videos ({((df['risk_score'] > 30) & (df['risk_score'] <= 70)).mean()*100:.1f}%)")
    print(f"High risk (71-100):  {(df['risk_score'] > 70).sum():6,} videos ({(df['risk_score'] > 70).mean()*100:.1f}%)")
    
    # Account characteristics
    print("\\n=== ACCOUNT CHARACTERISTICS ===")
    fraud_accounts = df[df['is_fraud'] == True]
    legit_accounts = df[df['is_fraud'] == False]
    
    print("Fraud accounts:")
    print(f"  Median followers: {fraud_accounts['followers'].median():,.0f}")
    print(f"  Median account age: {fraud_accounts['account_age_days'].median():.0f} days")
    print(f"  Verification rate: {fraud_accounts['is_verified'].mean()*100:.1f}%")
    
    print("Legitimate accounts:")
    print(f"  Median followers: {legit_accounts['followers'].median():,.0f}")
    print(f"  Median account age: {legit_accounts['account_age_days'].median():.0f} days")
    print(f"  Verification rate: {legit_accounts['is_verified'].mean()*100:.1f}%")
    
    # Most common fraud indicators
    print("\\n=== TOP FRAUD INDICATORS ===")
    all_indicators = []
    for indicators_str in fraud_accounts['fraud_indicators'].dropna():
        if indicators_str:
            all_indicators.extend(indicators_str.split('|'))
    
    from collections import Counter
    top_indicators = Counter(all_indicators).most_common(5)
    
    for indicator, count in top_indicators:
        percentage = (count / len(fraud_accounts)) * 100
        print(f"{indicator:25}: {count:6,} occurrences ({percentage:.1f}%)")
    
    print("\\n=== ANALYSIS COMPLETE ===")
    print("Dataset is ready for machine learning and fraud detection research!")

if __name__ == "__main__":
    analyze_dataset()
'''

with open('quick_analysis.py', 'w') as f:
    f.write(analysis_script)

print("\n=== ANALYSIS SCRIPT CREATED ===")
print("File saved: quick_analysis.py")
print("Run this script to get quick insights: python quick_analysis.py")

print(f"\n=== COMPLETE PACKAGE SUMMARY ===")
print(f"✅ Main dataset: tiktok_fraud_dataset_100k.csv (100,000 records)")
print(f"✅ Summary statistics: dataset_summary.csv")  
print(f"✅ ML training example: ml_training_example.py")
print(f"✅ Complete documentation: dataset_documentation.md")
print(f"✅ Quick analysis script: quick_analysis.py")
print(f"\nTotal files created: 5")
print(f"Ready for fraud detection model development!")