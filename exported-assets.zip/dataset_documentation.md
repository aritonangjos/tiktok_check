# TikTok Fraud Detection Dataset Documentation

## Overview
This synthetic dataset contains 100,000 TikTok video records designed for fraud detection research and model training. 

**Important:** This is synthetic data created for development and testing purposes only. It does not contain real TikTok data or personal information.

## Dataset Statistics
- **Total Records:** 100,000
- **Fraudulent Videos:** 54,291 (54.3%)
- **Legitimate Videos:** 45,709 (45.7%)
- **Features per Record:** 27
- **File Size:** ~101.6 MB
- **Time Period:** 90 days of synthetic activity
- **Unique Users:** 83,696

## Features Description

### Basic Information
- `video_id`: Unique identifier for each video (UUID format)
- `video_url`: Synthetic TikTok video URL
- `username`: TikTok username (synthetic)
- `title`: Video title/caption
- `upload_date`: Video upload timestamp

### Content Classification
- `category`: Content category (investment, giveaway, product, romance, phishing, entertainment, education, lifestyle)
- `primary_keyword`: Primary keyword associated with the content
- `is_fraud`: Binary target variable (True = fraud, False = legitimate)
- `risk_score`: Fraud risk score (0-100 scale)
- `risk_level`: Risk categorization (low, medium, high)
- `fraud_indicators`: Pipe-separated list of detected fraud indicators

### Account Features
- `followers`: Number of followers
- `following`: Number of accounts following
- `follower_following_ratio`: Ratio of followers to following
- `account_age_days`: Age of account in days
- `is_verified`: Verification status (Boolean)

### Engagement Metrics
- `view_count`: Number of video views
- `likes`: Number of likes
- `shares`: Number of shares
- `comments`: Number of comments
- `engagement_rate`: Overall engagement rate percentage
- `duration_seconds`: Video duration in seconds

### Additional Features
- `has_external_links`: Presence of external links (Boolean)
- `audio_language`: Audio language code
- `location_country`: Content creator's country

## Fraud Categories and Rates

| Category | Videos | Fraud Rate |
|----------|---------|------------|
| Giveaway | 20,249 | 90.0% |
| Phishing | 7,089 | 84.8% |
| Investment | 14,743 | 79.8% |
| Romance | 7,949 | 68.9% |
| Product | 25,069 | 40.1% |
| Lifestyle | 5,028 | 19.6% |
| Entertainment | 14,985 | 10.2% |
| Education | 4,888 | 5.0% |

## Common Fraud Indicators

1. **Suspicious engagement** (35.3% of fraud videos)
2. **Promises of easy money** (35.3% of fraud videos)
3. **New account** (35.1% of fraud videos)
4. **Fake giveaway** (35.0% of fraud videos)
5. **Urgent language** (35.0% of fraud videos)
6. **External links** (35.0% of fraud videos)
7. **Investment scheme** (34.9% of fraud videos)
8. **Requests personal info** (34.9% of fraud videos)
9. **Celebrity impersonation** (34.9% of fraud videos)
10. **Cryptocurrency promotion** (34.7% of fraud videos)

## Usage Examples

### Loading the Dataset
```python
import pandas as pd
df = pd.read_csv('tiktok_fraud_dataset_100k.csv')
print(f"Dataset shape: {df.shape}")
```

### Basic Analysis
```python
# Fraud distribution
fraud_rate = df['is_fraud'].mean()
print(f"Overall fraud rate: {fraud_rate:.1%}")

# Category analysis
category_fraud = df.groupby('category')['is_fraud'].mean().sort_values(ascending=False)
print("Fraud rate by category:")
print(category_fraud)
```

### Feature Engineering Examples
```python
# Create additional features
df['has_fraud_indicators'] = (df['fraud_indicators'] != '').astype(int)
df['likes_ratio'] = df['likes'] / (df['view_count'] + 1)
df['title_length'] = df['title'].str.len()
df['has_money_keywords'] = df['title'].str.contains('money|cash|free|$', case=False, na=False)
```

### Machine Learning Preparation
```python
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

# Select features
features = ['followers', 'engagement_rate', 'account_age_days', 'has_external_links']
X = df[features]
y = df['is_fraud']

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
```

## Applications

This dataset can be used for:

1. **Binary Classification**: Predict fraud vs. legitimate content
2. **Risk Scoring**: Develop risk scoring algorithms
3. **Pattern Analysis**: Identify fraud patterns and trends
4. **Feature Engineering**: Develop new fraud detection features
5. **Model Benchmarking**: Compare different ML algorithms
6. **Anomaly Detection**: Identify unusual patterns in social media content
7. **Educational Purposes**: Teaching fraud detection concepts

## File Structure

```
├── tiktok_fraud_dataset_100k.csv    # Main dataset (100K records)
├── dataset_summary.csv              # Summary statistics
├── ml_training_example.py           # ML training code example
└── README.md                        # This documentation
```

## Important Notes

- This is **synthetic data** created for development purposes
- Real TikTok data would require proper API access and privacy compliance
- The fraud patterns are based on research but may not reflect exact real-world distributions
- Always validate models on real data before production deployment
- Consider data privacy and ethical implications when working with social media data

## Citation

If using this dataset for research, please cite:
```
TikTok Fraud Detection Synthetic Dataset (2025)
Generated for fraud detection research and model development
100,000 synthetic video records with fraud indicators
```

## License

This synthetic dataset is provided for educational and research purposes only.
