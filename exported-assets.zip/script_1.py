# Create detailed analysis of the generated dataset
import matplotlib.pyplot as plt
import seaborn as sns

print("=== DETAILED DATASET ANALYSIS ===\n")

# Load the dataset for analysis
df = pd.read_csv("tiktok_fraud_dataset_100k.csv")

# 1. Fraud Distribution Analysis
print("1. FRAUD DISTRIBUTION BY CATEGORY:")
fraud_by_category = df.groupby('category').agg({
    'is_fraud': ['count', 'sum', 'mean']
}).round(3)
fraud_by_category.columns = ['Total_Videos', 'Fraud_Videos', 'Fraud_Rate']
fraud_by_category = fraud_by_category.sort_values('Fraud_Rate', ascending=False)
print(fraud_by_category)

print("\n2. RISK SCORE ANALYSIS:")
risk_ranges = ['Low (0-30)', 'Medium (31-70)', 'High (71-100)']
risk_counts = [
    len(df[df['risk_score'] <= 30]),
    len(df[(df['risk_score'] > 30) & (df['risk_score'] <= 70)]),
    len(df[df['risk_score'] > 70])
]

for i, (range_name, count) in enumerate(zip(risk_ranges, risk_counts)):
    percentage = (count / len(df)) * 100
    print(f"  {range_name}: {count:,} videos ({percentage:.1f}%)")

print("\n3. ACCOUNT CHARACTERISTICS BY FRAUD STATUS:")
account_stats = df.groupby('is_fraud').agg({
    'followers': ['median', 'mean'],
    'following': ['median', 'mean'],
    'account_age_days': ['median', 'mean'],
    'is_verified': 'mean',
    'engagement_rate': ['median', 'mean']
}).round(2)

print("Fraudulent Accounts:")
print(f"  Median followers: {account_stats.loc[True, ('followers', 'median')]:,.0f}")
print(f"  Median following: {account_stats.loc[True, ('following', 'median')]:,.0f}")
print(f"  Median account age: {account_stats.loc[True, ('account_age_days', 'median')]:.0f} days")
print(f"  Verification rate: {account_stats.loc[True, ('is_verified', 'mean')]*100:.1f}%")
print(f"  Median engagement rate: {account_stats.loc[True, ('engagement_rate', 'median')]:.2f}%")

print("\nLegitimate Accounts:")
print(f"  Median followers: {account_stats.loc[False, ('followers', 'median')]:,.0f}")
print(f"  Median following: {account_stats.loc[False, ('following', 'median')]:,.0f}")
print(f"  Median account age: {account_stats.loc[False, ('account_age_days', 'median')]:.0f} days")
print(f"  Verification rate: {account_stats.loc[False, ('is_verified', 'mean')]*100:.1f}%")
print(f"  Median engagement rate: {account_stats.loc[False, ('engagement_rate', 'median')]:.2f}%")

print("\n4. ENGAGEMENT PATTERNS:")
engagement_by_fraud = df.groupby('is_fraud').agg({
    'view_count': ['median', 'mean'],
    'likes': ['median', 'mean'],
    'shares': ['median', 'mean'],
    'comments': ['median', 'mean']
}).round(0)

print("Fraudulent Videos (median engagement):")
print(f"  Views: {engagement_by_fraud.loc[True, ('view_count', 'median')]:,.0f}")
print(f"  Likes: {engagement_by_fraud.loc[True, ('likes', 'median')]:,.0f}")
print(f"  Shares: {engagement_by_fraud.loc[True, ('shares', 'median')]:,.0f}")
print(f"  Comments: {engagement_by_fraud.loc[True, ('comments', 'median')]:,.0f}")

print("\nLegitimate Videos (median engagement):")
print(f"  Views: {engagement_by_fraud.loc[False, ('view_count', 'median')]:,.0f}")
print(f"  Likes: {engagement_by_fraud.loc[False, ('likes', 'median')]:,.0f}")
print(f"  Shares: {engagement_by_fraud.loc[False, ('shares', 'median')]:,.0f}")
print(f"  Comments: {engagement_by_fraud.loc[False, ('comments', 'median')]:,.0f}")

print("\n5. TOP FRAUD INDICATORS:")
# Count fraud indicators
all_indicators = []
fraud_videos = df[df['is_fraud'] == True]
for indicators_str in fraud_videos['fraud_indicators']:
    if pd.notna(indicators_str) and indicators_str != '':
        all_indicators.extend(indicators_str.split('|'))

from collections import Counter
indicator_counts = Counter(all_indicators)

print("Most common fraud indicators:")
for indicator, count in indicator_counts.most_common(10):
    percentage = (count / len(fraud_videos)) * 100
    print(f"  {indicator}: {count:,} occurrences ({percentage:.1f}% of fraud videos)")

print("\n6. GEOGRAPHIC AND LANGUAGE DISTRIBUTION:")
print("Top countries:")
country_dist = df['location_country'].value_counts()
for country, count in country_dist.head(8).items():
    percentage = (count / len(df)) * 100
    fraud_rate = df[df['location_country'] == country]['is_fraud'].mean() * 100
    print(f"  {country}: {count:,} videos ({percentage:.1f}%) - {fraud_rate:.1f}% fraud rate")

print("\nTop languages:")
lang_dist = df['audio_language'].value_counts()
for lang, count in lang_dist.head(5).items():
    percentage = (count / len(df)) * 100
    fraud_rate = df[df['audio_language'] == lang]['is_fraud'].mean() * 100
    print(f"  {lang}: {count:,} videos ({percentage:.1f}%) - {fraud_rate:.1f}% fraud rate")

print("\n7. TEMPORAL PATTERNS:")
df['upload_date'] = pd.to_datetime(df['upload_date'])
df['upload_hour'] = df['upload_date'].dt.hour
df['upload_day_of_week'] = df['upload_date'].dt.day_name()

print("Fraud rate by hour of day (top fraud hours):")
hourly_fraud = df.groupby('upload_hour')['is_fraud'].agg(['count', 'mean']).round(3)
hourly_fraud.columns = ['Total_Posts', 'Fraud_Rate']
hourly_fraud = hourly_fraud.sort_values('Fraud_Rate', ascending=False)
print(hourly_fraud.head(8))

print(f"\n=== DATASET SUMMARY ===")
print(f"Total records: {len(df):,}")
print(f"Features per record: {len(df.columns)}")
print(f"Dataset size: ~101.6 MB")
print(f"Fraud detection accuracy baseline: {max(df['is_fraud'].mean(), 1-df['is_fraud'].mean())*100:.1f}% (majority class)")
print(f"Data covers: {(df['upload_date'].max() - df['upload_date'].min()).days} days")
print(f"Unique users: {df['username'].nunique():,}")
print(f"Average videos per user: {len(df) / df['username'].nunique():.1f}")

# Create summary statistics CSV
summary_stats = pd.DataFrame({
    'Metric': [
        'Total Videos', 'Fraudulent Videos', 'Legitimate Videos', 
        'Fraud Rate (%)', 'High Risk Videos', 'Medium Risk Videos', 'Low Risk Videos',
        'Verified Accounts', 'Average Followers (Median)', 'Average Account Age (Days)',
        'Most Common Fraud Type', 'Highest Risk Category'
    ],
    'Value': [
        f"{len(df):,}",
        f"{df['is_fraud'].sum():,}",
        f"{(~df['is_fraud']).sum():,}",
        f"{df['is_fraud'].mean()*100:.1f}%",
        f"{(df['risk_score'] >= 71).sum():,}",
        f"{((df['risk_score'] >= 31) & (df['risk_score'] < 71)).sum():,}",
        f"{(df['risk_score'] < 31).sum():,}",
        f"{df['is_verified'].sum():,}",
        f"{df['followers'].median():,.0f}",
        f"{df['account_age_days'].median():.0f}",
        fraud_by_category.index[0].title(),
        fraud_by_category.index[0].title()
    ]
})

summary_stats.to_csv('dataset_summary.csv', index=False)
print(f"\nSummary statistics saved to: dataset_summary.csv")

# Create feature importance data for ML
print(f"\n8. FEATURES FOR MACHINE LEARNING:")
numerical_features = ['followers', 'following', 'follower_following_ratio', 'account_age_days', 
                     'duration_seconds', 'view_count', 'likes', 'shares', 'comments', 'engagement_rate', 'risk_score']
categorical_features = ['category', 'risk_level', 'audio_language', 'location_country', 'is_verified', 'has_external_links']
text_features = ['title', 'primary_keyword', 'fraud_indicators']

print(f"Numerical features ({len(numerical_features)}): {', '.join(numerical_features)}")
print(f"Categorical features ({len(categorical_features)}): {', '.join(categorical_features)}")
print(f"Text features ({len(text_features)}): {', '.join(text_features)}")
print(f"Total features available for ML: {len(numerical_features) + len(categorical_features) + len(text_features)}")

print(f"\nThis synthetic dataset is ready for:")
print(f"  ✓ Training machine learning models")
print(f"  ✓ Testing fraud detection algorithms")
print(f"  ✓ Developing classification systems")
print(f"  ✓ Benchmarking detection performance")
print(f"  ✓ Analyzing fraud patterns and trends")