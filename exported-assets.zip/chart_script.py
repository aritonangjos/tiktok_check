import pandas as pd
import plotly.graph_objects as go

# Create DataFrame from the provided data
data = [
    {"category": "giveaway", "total": 20249, "fraud": 18217, "fraud_rate": 0.9},
    {"category": "phishing", "total": 7089, "fraud": 6014, "fraud_rate": 0.848},
    {"category": "investment", "total": 14743, "fraud": 11760, "fraud_rate": 0.798},
    {"category": "romance", "total": 7949, "fraud": 5477, "fraud_rate": 0.689},
    {"category": "product", "total": 25069, "fraud": 10062, "fraud_rate": 0.401},
    {"category": "lifestyle", "total": 5028, "fraud": 988, "fraud_rate": 0.196},
    {"category": "entertainment", "total": 14985, "fraud": 1529, "fraud_rate": 0.102},
    {"category": "education", "total": 4888, "fraud": 244, "fraud_rate": 0.05}
]

df = pd.DataFrame(data)

# Create pie chart showing fraud distribution by category
# Calculate total fraud cases for percentage calculation
total_fraud = df['fraud'].sum()

# Create pie chart
fig = go.Figure(data=[go.Pie(
    labels=df['category'],
    values=df['fraud'],
    textinfo='label+percent',
    textposition='inside',
    marker=dict(colors=['#1FB8CD', '#DB4545', '#2E8B57', '#5D878F', '#D2BA4C', 
                       '#B4413C', '#964325', '#944454'])
)])

# Update layout
fig.update_layout(
    title='TikTok Fraud Distribution by Category',
    uniformtext_minsize=14, 
    uniformtext_mode='hide'
)

# Save as PNG and SVG
fig.write_image('chart.png')
fig.write_image('chart.svg', format='svg')